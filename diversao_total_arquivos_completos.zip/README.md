# Diversão Total — PWA inicial

Projeto inicial instalável para celular Android, feito com HTML, CSS e JavaScript sem dependências.

## Arquivos
- `index.html`: interface e funcionalidades demonstrativas.
- `manifest.json`: configuração do aplicativo web instalável.
- `sw.js`: cache básico para abrir a interface offline após a primeira visita.
- `icons/`: ícones SVG do aplicativo.

## Publicar gratuitamente usando apenas o celular
1. Extraia o ZIP no celular, se necessário.
2. Abra https://github.com e crie/entre na sua conta.
3. Crie um repositório público chamado `diversao-total`.
4. Use **Add file > Upload files** e envie `index.html`, `manifest.json`, `sw.js` e a pasta `icons` com seus dois SVGs. Não envie somente o ZIP: o GitHub Pages precisa dos arquivos extraídos.
5. Toque em **Commit changes**.
6. No repositório, abra **Settings > Pages**. Em **Build and deployment**, escolha **Deploy from a branch**, branch `main`, pasta `/(root)` e salve.
7. Aguarde a publicação. O endereço normalmente será `https://SEU-USUARIO.github.io/diversao-total/`.
8. Abra o endereço no Chrome Android, menu ⋮ e escolha **Instalar app** ou **Adicionar à tela inicial**.

## Limites desta primeira versão
Esta versão contém telas e interações locais demonstrativas. Perfil, favoritos e mensagens são salvos apenas no navegador deste aparelho; não há contas online nem chat entre usuários. Catálogos de vídeo, música, filmes e lives precisam de fontes e conteúdo autorizado. Para funcionalidades multiusuário, será necessário integrar um backend e configurar segurança e privacidade.
